function [dydt] = Infante_3(x,theta1,theta2,theta3,rudder)
% function [dydt,sm,Len,YY,X,Y,N] = Infante_3d(x,sm)
% a ship of Infante. While the state vector is defined as follows:
% u     = surge velocity          (m/s)
% v     = sway velocity           (m/s)
% r     = yaw velocity            (rad/s)
% p     = roll velocity           (rad/s)
% x_p  = position in x-direction (m)
% y_p  = position in y-direction (m)
% psi  = yaw angle               (rad)
% phi  = roll angle              (rad)

%Status variables
dydt = zeros(6,1);
u = x(1); v = x(2); 
r = x(3); 
x_p = x(4); 
y_p = x(5); 
psi = x(6); 
d=rudder;
ua = u-1.179;
A = theta1'; B = theta2'; C = theta3';
%Speed and rudder state volume matrix
X = [ua,v*v,r*r,d*d,v*r,v*d,r*d]';
Y = [v,abs(v)*v,abs(r)*v,r,abs(v)*r,abs(r)*r,d]';
N = [v,abs(v)*v,abs(r)*v,r,abs(v)*r,abs(r)*r,d]';

%Acceleration in J + measure
dydt(1) = A*X;
dydt(2) = B*Y;
dydt(3) = C*N;                                                                                                    
%Coordinate system matrix transformation
%Displacement interpolation
phi=0;
dydt(4) = u*cos(psi)-v*cos(phi)*sin(psi); %dx   
dydt(5) = u*sin(psi)+v*cos(phi)*cos(psi); %dy
%Angle interpolation
dydt(6) = r*cos(phi);%dpsi                      















